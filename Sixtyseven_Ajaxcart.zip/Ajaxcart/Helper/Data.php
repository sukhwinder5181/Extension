<?php
/**
 * @category  SixtySeven
 * @package   SixtySeven_Ajaxsuite
 * @author    SixtySeven https://67commerce.com/
 */
namespace SixtySeven\Ajaxcart\Helper;

/**
 * Helper Class
 */
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{

    /**
     * $priceHelper
     * @var \Magento\Framework\Pricing\Helper\Data
     */
    protected $priceHelper;

    /**
     * __construct
     * @param \Magento\Framework\App\Helper\Context  $context     [description]
     * @param \Magento\Framework\Pricing\Helper\Data $priceHelper [description]
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Framework\Pricing\Helper\Data $priceHelper
    ) {
        $this->priceHelper = $priceHelper;
        parent::__construct($context);
    }

    /**
     * getPriceWithCurrency
     * @param  float $price [description]
     * @return float
     */
    public function getPriceWithCurrency($price)
    {
        if ($price) {
            //remore , as thousend seprator
            return $this->priceHelper->currency(number_format($price, 2, '.', ''), true, false);
        }
        return 0;
    }
}
