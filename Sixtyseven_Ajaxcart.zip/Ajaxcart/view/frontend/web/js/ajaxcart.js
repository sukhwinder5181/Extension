/**
 * @category  SixtySeven
 * @package   SixtySeven_Ajaxsuite
 * @author    SixtySeven https://67commerce.com/
 */
define([
    'jquery',
    'Magento_Ui/js/modal/modal',
    'SixtySeven_AjaxsuiteBase/js/base',
    'jquery/ui',
    'mage/translate',
    'jquery/validate',
    'mage/validation/validation'
], function($j, modal, parentbase) {
    'use strict';
    $j.widget('sixtyseven.ajaxcart', {
        options: {
            submitUrl: '',
            formSubmitUrl: '',
            canExecuteJs: 1,
            autoMinicartOpen: 0,
            cartConfirmPopup: 1,
            canShowSuggestion: 0,
            addToCartSelector: '.action.tocart',
            canShowContinueBtn: 1,
            continueBtnText: 'Continue',
            canShowCheckoutBtn: 1,
            checkoutBtnText: 'Checkout',
            canShowCartBtn: 1,
            cartBtnText: 'Go to cart',
            checkOutUrl: '',
            cartUrl: '',
            form_key: '',
            canAutoClosePopup: 0,
            closePopupTime: 15,
            canShowTimer: 0,
            overrideClick: 1,
            showRemoveConfirmation: 1,
            popupOptions: {
                type: 'popup',
                responsive: true,
                innerScroll: true,
                title: '',
                buttons: [],
                wrapperClass: 'modals-wrapper medium-popup'
            }
        },
        _popupobj: false,
        _targetModel: '#ss_model_dynamic',
        _cartMainForm: '#form-validate.form.form-cart',
        _msgTemp: '<div id="ajaxcart_error_msg" class="messages"><div class="{{type}} message message-{{type}}"><div>{{msg_text}}</div></div></div>',
        _create: function() {
            this._initElement();
            window.ajaxAddCart = this;
        },
        _initElement: function() {
            var options = this.options,
                self = this,
                data,
                item_id;

            if (options.canExecuteJs == 0) {
                return false;
            }

            if (options.overrideClick == 1) {
                self.element.find(options.addToCartSelector).unbind('click');
            }

            self.element.on('click', options.addToCartSelector, function(event) {
                event.preventDefault();
                event.stopPropagation();
                self.addToCart(this);
                return false;
            });

            self.element.on('submit', self._cartMainForm, function(event) {
                event.preventDefault();
                event.stopPropagation();
                self.submitCartForm(this);
                return false;
            });

            self.element.on('click', '#shopping-cart-table .action.action-delete', function(event) {
                data = $j(this).data('post');
                item_id = data.data.id;
                if (typeof item_id != 'undefined' && parseInt(item_id) > 0) {
                    event.preventDefault();
                    event.stopPropagation();
                    $j('[name="cart[' + item_id + '][qty]"]').val('0');
                    self.submitCartForm($j(self._cartMainForm));
                    return false;
                }
            });

        },
        submitCartForm: function(element) {
            var options = this.options,
                self = this,
                dataForm = {},
                jcontent,
                parent,
                temp,
                messages,
                msghtml,
                newhtm,
                replaceContainer = false;

            $j(element).find('input, select, textarea').each(function() {
                dataForm[$j(this).attr('name')] = $j(this).val();
                //dataForm.append($j(element).attr('name'), $j(element).val());
            });

            if (typeof dataForm.form_key == 'undefined') {
                dataForm['form_key'] = options.form_key;
            }

            self._callAjax(options.formSubmitUrl, dataForm, {
                complete: function(response) {
                    try {
                        jcontent = response.responseJSON;

                        self.options.form_key = jcontent.form_key;

                        parent = $j('div.cart-container').closest('.column.main');
                        $j(parent).find('[name="form_key"]').val(jcontent.form_key);

                        //re3nder message
                        messages = jcontent.messages
                        msghtml = '';

                        if (messages.length > 0) {

                            for (var i in messages) {
                                temp = _msgTemp.replace('{{type}}', messages[i].type);
                                temp = temp.replace('{{msg_text}}', messages[i].text);
                                msghtml += temp;
                            }

                        }

                        $j('#ajaxcart_error_msg').remove();
                        $j('div.page.messages').append(msghtml);

                        //reder cart table
                        var tmpInput = document.createElement('div');
                        $j(tmpInput).html(jcontent.output_html);

                        newhtm = $j(tmpInput).find(self._cartMainForm).html();


                        if (typeof newhtm == 'undefined') {
                            replaceContainer = true;
                            newhtm = $j(tmpInput).find('.ajax-cart-container-content').html();
                        }

                        $j(tmpInput).remove();


                        if (replaceContainer === true) {

                            $j(parent).find('div.cart-container').html(newhtm);
                            $j(parent).trigger('contentUpdated');

                        } else if (replaceContainer === false) {

                            $j(parent).find(self._cartMainForm).html(newhtm);
                            $j(self._cartMainForm).trigger('contentUpdated');

                            require(['Magento_Checkout/js/action/get-totals', 'Magento_Checkout/js/model/quote'], function(getTotalsAction, quote) {
                                var method = quote.shippingMethod(),
                                    deferred = $j.Deferred();

                                deferred.done(function() {

                                    if (method != null && typeof method != 'undefined' && method != 'undefined') {
                                        // jQuery('#shipping-zip-form [name="postcode"]').trigger('keyup');
                                        quote.shippingMethod(method);
                                    }

                                });

                                getTotalsAction([], deferred);

                            });

                        }
                    } catch (e) {
                        console.log(e);
                    }

                },
                error: function() {
                    window.location.href = actionUrl;
                }
            });
        },
        addToCart: function(element) {
            var options = this.options,
                self = this,
                data = '',
                parentForm = $j(element).closest('form'),
                canProceed,
                actionUrl,
                serializeData,
                productId,
                dataForm = {};

            if (parentForm.length > 0) {

                actionUrl = $j(parentForm).attr('action');
                serializeData = $j(parentForm).serialize();
                productId = self._checkProductId(parentForm, element, actionUrl);

                if ($j.isNumeric(productId)) {
                    //if product id find then

                    if ($j.trim(serializeData) == '') {
                        $j(parentForm).find('input, select, textarea').each(function() {
                            dataForm[$j(this).attr('name')] = $j(this).val();
                        });

                        if (typeof dataForm.product == 'undefined' || !$j.isNumeric(dataForm.product)) {
                            dataForm['product'] = productId;
                        }

                        dataForm['form_key'] = options.form_key;
                        data = dataForm;
                    } else {
                        data = serializeData;
                    }

                    self._callAjax(options.submitUrl, data, {
                        error: function() {
                            window.location.href = actionUrl;
                        }
                    });

                } else {
                    //if product id not found for this element event
                    //check if its wishlist item to add to cart
                    self._proceedIfWishlist(element);
                }

            } else {
                //check if its wishlist item to add to cart
                self._proceedIfWishlist(element);
            }
        },
        _proceedIfWishlist: function(element) {
            var options = this.options,
                self = this,
                formdata = $j(element).data('post'),
                sendData;

            sendData = $j.extend({}, formdata.data, {
                'form_key': options.form_key
            });

            if (typeof formdata.data != 'undefined' && typeof formdata.data.item != 'undefined' && isNaN(formdata.data.item) == false) {
                //it means its wishlist add to cart
                self._callAjax(options.wishlistSubmitUrl, sendData, {
                    error: function() {
                        window.location.href = self.options.wishListUrl;
                    }
                }, false);

            } else if (typeof formdata.data != 'undefined' && typeof formdata.data.product != 'undefined' && isNaN(formdata.data.product) == false) {
                //it means its product add to cart
                self._callAjax(options.submitUrl, sendData, {
                    error: function() {
                        window.location.href = actionUrl;
                    }
                });
            }
        },
        _checkProductId: function(form, element, url) {
            var self = this,
                prodIdEleNames = ["product", "product-id", "data-product-id", "data-product"],
                id,
                hasItemId = $j(element).data('item-id'),
                item,
                array,
                i,
                priceBox;

            //check if its wishlist add to cart

            if (hasItemId > 0 && ($j(element).closest('#wishlist-view-form').length > 0 || $j(element).closest('#wishlist-sidebar').length > 0)) {
                return false;
            }

            if (form) {
                $j(form).find('input').each(function() {
                    if (prodIdEleNames.indexOf($j(this).attr('name')) >= 0) {
                        if ($j.isNumeric($j(this).val())) {
                            id = $j(this).val();
                        }
                    }
                });

                if ($j.isNumeric(id)) {
                    return id;
                }
            }

            id = $j(element).attr('data-product-id');

            if ($j.isNumeric(id)) {
                return id;
            }

            item = $j(element).closest('li.product-item');
            id = $j(item).find('[data-product-id]').attr('data-product-id');

            if ($j.isNumeric(id)) {
                return id;
            }


            if (url) {
                array = url.split('/');

                for (i = 0; i < array.length; i++) {
                    if (prodIdEleNames.indexOf(array[i]) >= 0) {
                        if ($j.isNumeric(array[i + 1])) {
                            id = array[i + 1];
                        }
                    }
                }

                if ($j.isNumeric(id)) {
                    return id;
                }
            }

            priceBox = $j(element).closest('.price-box.price-final_price');
            id = priceBox.attr('data-product-id');

            if ($j.isNumeric(id)) {
                return id;
            }
            return false;
        },
        _callAjax: function(url, formdata, additional) {
            var self = this,
                options = self.options,
                popupId = '#ss_ajax_suite_popup',
                config,
                jcontent,
                noptions,
                newconfig,
                canShowPopup = true;

            config = {
                type: 'POST',
                data: formdata,
                showLoader: true,
                dataType: 'json',
                beforeSend: function() {
                    //$j('#loading-mask').css('display','block');
                },
                complete: function(response) {
                    try {
                        jcontent = response.responseJSON;
                        noptions = options.popupOptions;
                        noptions.title = jcontent.title;

                        if (typeof jcontent.hasoption == 'undefined' && options.autoMinicartOpen == 1) {
                            jQuery("[data-block='minicart']").trigger('contentLoading');

                            $j("[data-block='minicart']").one('contentUpdated', function () {
                                $j("[data-block='minicart']").find('._block-content-loading [data-role="loader"]').remove();
                                $j("[data-block='minicart']").find('._block-content-loading').removeClass('_block-content-loading');
                                $j("[data-block='minicart']").find('[data-role="dropdownDialog"]').dropdownDialog("open");
                            });
                        }

                        self.options.form_key = jcontent.form_key;
                        

                        if (typeof jcontent.hasoption == 'undefined' && jcontent.hasoption != 1) {
                            noptions.buttons = self._getPopupButtons();
                        } else {
                            noptions.buttons = [];
                        }

                        if((typeof jcontent.hasoption=='undefined' || jcontent.hasoption!=1) && options.cartConfirmPopup==0)
                        {
                            canShowPopup = false;
                        }

                        if (self._popupobj !== false)
                            self._popupobj.closeModal();

                        if(canShowPopup==true){
                            $j(self._targetModel).html(jcontent.content);
                            self._popupobj = modal(noptions, $j(popupId));
                            self._popupobj.openModal();
                            $j(popupId).trigger('contentUpdated');

                        }
                        /*jQuery("[data-block='minicart']").one('contentUpdated', function () {
                            jQuery("[data-block='minicart']").find('[data-role="dropdownDialog"]').dropdownDialog("open");
                        });*/


                    } catch (e) {
                        console.log(e);
                    }

                },
                error: function(response) {
                    alert($j.mage.__('Something went wrong'));
                }
            };

            newconfig = $j.extend({}, config, additional);
            $j.ajax(url, newconfig);
        },
        _getPopupButtons: function() {
            var options = this.options,
                buttons = [],
                timeinsec;

            if (options.canShowContinueBtn == 1 || options.canAutoClosePopup == 1) {
                buttons.push({
                    text: $j.mage.__(options.continueBtnText),
                    class: 'continue-btn-inpopup-timer-cartbtn',
                    click: function() {
                        $j('button.continue-btn-inpopup-timer-cartbtn').find('b').remove();
                        parentbase.setTimerObj(false);
                        this.closeModal();
                    }
                });

                if (options.canAutoClosePopup == '1') {
                    timeinsec = parseInt(options.closePopupTime) < 10 ? 10 : parseInt(options.closePopupTime);
                    setTimeout(function() {
                        if (options.canShowTimer == 1) {
                            parentbase.startTimer($j('button.continue-btn-inpopup-timer-cartbtn'), timeinsec);
                        } else {
                            setTimeout(function() {
                                self._popupobj.closeModal();
                            }, timeinsec);
                        }
                    }, 2000);
                }
            }

            if (options.canShowCheckoutBtn == 1) {
                buttons.push({
                    text: $j.mage.__(options.checkoutBtnText),
                    class: '',
                    click: function() {
                        this.closeModal();
                        window.location.href = options.checkOutUrl;
                    }
                });
            }

            if (options.canShowCartBtn == 1) {
                buttons.push({
                    text: $j.mage.__(options.cartBtnText),
                    class: '',
                    click: function() {
                        this.closeModal();
                        window.location.href = options.cartUrl;
                    }
                });
            }

            return buttons;
        }

    });
    return $j.sixtyseven.ajaxcart;
});