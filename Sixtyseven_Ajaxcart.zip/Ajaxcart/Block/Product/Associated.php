<?php
/**
 * @category  SixtySeven
 * @package   SixtySeven_Ajaxsuite
 * @author    SixtySeven https://67commerce.com/
 */
namespace SixtySeven\Ajaxcart\Block\Product;

/**
 * Associated product block 
 */
class Associated extends \Magento\Catalog\Block\Product\AbstractProduct
{
    
    /**
     * @var \SixtySeven\AjaxsuiteBase\Block\AbstractBlock
     */
    protected $baseBlock;

    /**
     * current block is used for module
     */
    const BLOCKTYPE = 'cart';
    
    
    /**
     *  item collection
     *
     * @var \Magento\Catalog\Model\ResourceModel\Product\Link\Product\Collection
     */
    protected $_itemCollection;

    /**
     * @param \Magento\Catalog\Block\Product\Context $context
     * @param \Magento\Checkout\Model\ResourceModel\Cart $checkoutCart
     * @param \Magento\Catalog\Model\Product\Visibility $catalogProductVisibility
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param \Magento\Framework\Module\Manager $moduleManager
     * @param \SixtySeven\AjaxsuiteBase\Block\AbstractBlock $baseBlock
     * @param array $data
     */
    public function __construct(
        \Magento\Catalog\Block\Product\Context $context,
        \Magento\Checkout\Model\ResourceModel\Cart $checkoutCart,
        \Magento\Catalog\Model\Product\Visibility $catalogProductVisibility,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Framework\Module\Manager $moduleManager,
        \SixtySeven\AjaxsuiteBase\Block\AbstractBlock $baseBlock,
        array $data = []
    ) {
        $this->_checkoutCart = $checkoutCart;
        $this->_catalogProductVisibility = $catalogProductVisibility;
        $this->_checkoutSession = $checkoutSession;
        $this->moduleManager = $moduleManager;
        $this->baseBlock = $baseBlock;
        parent::__construct(
            $context,
            $data
        );
    }
    
    /**
     * Get associated product type for this module
     * @return string
     */
    public function getType()
    {
       return $this->baseBlock->getAssociatedType(self::BLOCKTYPE);
    } 

    /**
     * Get associated product section title
     * @return string
     */
    public function getAssociatedTitle()
    {
        return $this->baseBlock->getTitleByType(self::BLOCKTYPE);
    }

    /**
     * Prepare crosssell items data
     *
     * @return \Magento\Catalog\Block\Product\ProductList\Crosssell
     */
    protected function _prepareData()
    {
        $product = $this->_coreRegistry->registry('product');
        /* @var $product \Magento\Catalog\Model\Product */
        $productType = $this->getType();

        switch ($productType) {
            case 'related':
                $this->_itemCollection = $product->getRelatedProductCollection()->addAttributeToSelect(
                    'required_options'
                );//->setPositionOrder();

                $defaultOrder = explode("_", $this->baseBlock->getAssociatedOrder(self::BLOCKTYPE));
                $order = $defaultOrder[0];
                $type = isset($defaultOrder[1])? $defaultOrder[1]: 'ASC';


                $this->_itemCollection->addAttributeToSort($order, strtoupper($type));


                $this->_itemCollection->addStoreFilter();

                if ($this->moduleManager->isEnabled('Magento_Checkout')) {
                    $this->_addProductAttributesAndPrices($this->_itemCollection);
                }
                
                $this->_itemCollection->setVisibility($this->_catalogProductVisibility->getVisibleInCatalogIds());

                $this->_itemCollection 
                    ->setPageSize($this->baseBlock->getAssociatedLimit(self::BLOCKTYPE)) // only get 10 products 
                    ->setCurPage(1);

                $this->_itemCollection->load();

                foreach ($this->_itemCollection as $product) {
                    $product->setDoNotUseCategoryId(true);
                }

                break;
            case 'upsell':
                $this->_itemCollection = $product->getUpSellProductCollection();//->setPositionOrder()->addStoreFilter();


                $defaultOrder = explode("_", $this->baseBlock->getAssociatedOrder(self::BLOCKTYPE));
                $order = $defaultOrder[0];
                $type = isset($defaultOrder[1])? $defaultOrder[1]: 'ASC';


                $this->_itemCollection->addAttributeToSort($order, strtoupper($type));


                $this->_itemCollection->addStoreFilter();

                if ($this->moduleManager->isEnabled('Magento_Checkout')) {
                    $this->_addProductAttributesAndPrices($this->_itemCollection);
                }
                $this->_itemCollection->setVisibility($this->_catalogProductVisibility->getVisibleInCatalogIds());

                $this->_itemCollection 
                    ->setPageSize($this->baseBlock->getAssociatedLimit(self::BLOCKTYPE)) // only get 10 products 
                    ->setCurPage(1);

                $this->_itemCollection->load();

                /**
                 * Updating collection with desired items
                 */
                $this->_eventManager->dispatch(
                    'catalog_product_upsell',
                    ['product' => $product, 'collection' => $this->_itemCollection, 'limit' => null]
                );

                foreach ($this->_itemCollection as $product) {
                    $product->setDoNotUseCategoryId(true);
                }

                break;
            case 'crosssell':
                 $this->_itemCollection = $product->getCrossSellProductCollection()->addAttributeToSelect(
                    $this->_catalogConfig->getProductAttributes()
                );//->setPositionOrder()->addStoreFilter();

                $defaultOrder = explode("_", $this->baseBlock->getAssociatedOrder(self::BLOCKTYPE));
                $order = $defaultOrder[0];
                $type = isset($defaultOrder[1])? $defaultOrder[1]: 'ASC';


                $this->_itemCollection->addAttributeToSort($order, strtoupper($type));


                $this->_itemCollection->addStoreFilter();

                $this->_itemCollection 
                    ->setPageSize($this->baseBlock->getAssociatedLimit(self::BLOCKTYPE)) // only get 10 products 
                    ->setCurPage(1);

                $this->_itemCollection->load();

                foreach ($this->_itemCollection as $product) {
                    $product->setDoNotUseCategoryId(true);
                }

                break;
        } 
        return $this;
    } 

    /**
     * Before rendering html process
     * Prepare items collection
     *
     * @return \Magento\Catalog\Block\Product\ProductList\Crosssell
     */
    protected function _beforeToHtml()
    {
        $this->_prepareData();
        return parent::_beforeToHtml();
    }

    /**
     * get item collection
     * @return Collection
     */
    public function getItems()
    {
        /**
         * getIdentities() depends on _itemCollection populated, but it can be empty if the block is hidden
         * @see https://github.com/magento/magento2/issues/5897
         */
        if (is_null($this->_itemCollection)) {
            $this->_prepareData();
        }
        return $this->_itemCollection;
    }

    /**
     * Return identifiers for produced content
     *
     * @return array
     */
    public function getIdentities()
    {
        $identities = [];
        foreach ($this->getItems() as $item) {
            $identities = array_merge($identities, $item->getIdentities());
        }
        return $identities;
    }

    /**
     * Find out if some products can be easy added to cart
     *
     * @return bool
     */
    public function canItemsAddToCart()
    {
        foreach ($this->getItems() as $item) {
            if (!$item->isComposite() && $item->isSaleable() && !$item->getRequiredOptions()) {
                return true;
            }
        }
        return false;
    }
}