<?php
/**
 * @category  SixtySeven
 * @package   SixtySeven_Ajaxsuite
 * @author    SixtySeven https://67commerce.com/
 */
namespace SixtySeven\Ajaxcart\Block\Product;

/**
 * Product Options block
 */
class Options extends \Magento\Framework\View\Element\Template
{

    /**
     * @var \Magento\Framework\Registry
     */
    protected $coreRegistry;

    /**
     * @var \Magento\Checkout\Block\Cart\Item\Renderer
     */
    protected $itemrenderer;
    /**
     * @var \Magento\Checkout\Block\Cart\Item\Renderer
     */
    protected $configurableRenderer;
    /**
     * @var \Magento\Checkout\Block\Cart\Item\Renderer
     */
    protected $bundleRenderer;

    /**
     * @var \SixtySeven\AjaxsuiteBase\Block\AbstractBlock
     */
    private $baseBlock;

    /**
     *
     * @param \Magento\Framework\View\Element\Template\Context $context       [description]
     * @param \SixtySeven\AjaxsuiteBase\Block\AbstractBlock    $baseBlock     [description]
     * @param \Magento\Checkout\Block\Cart\Item\Renderer       $_itemrenderer [description]
     * @param \Magento\Framework\Registry                      $registry      [description]
     * @param array                                            $data          [description]
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \SixtySeven\AjaxsuiteBase\Block\AbstractBlock $baseBlock,
        \Magento\Checkout\Block\Cart\Item\Renderer $_itemrenderer,
        \Magento\ConfigurableProduct\Block\Cart\Item\Renderer\Configurable $configurableRenderer,
        \Magento\Bundle\Block\Checkout\Cart\Item\Renderer $bundleRenderer,
        \Magento\Framework\Registry $registry,
        array $data
    ) {
        parent::__construct($context, $data);
        $this->itemrenderer         = $_itemrenderer;
        $this->configurableRenderer = $configurableRenderer;
        $this->bundleRenderer       = $bundleRenderer;
        $this->coreRegistry         = $registry;
        $this->baseBlock            = $baseBlock;
    }

    /**
     * getCurrentItem
     * @return \Magento\Quote\Model\Item
     */
    public function getCurrentItem()
    {
        return $this->coreRegistry->registry('current_item');
    }

    /**
     * 
     * getCurrentItemRenderer
     * @return \Magento\Checkout\Block\Cart\Item\Renderer
     */
    public function getCurrentItemRenderer()
    {
        $item         = $this->getCurrentItem();
        $itemrenderer = $this->itemrenderer; //default item renderer
        if ($item and $item->getId()) {
            $type = $item->getProduct()->getTypeId();
            switch ($type) {
                case 'configurable':
                    $itemrenderer = $this->configurableRenderer;
                    break;
                case 'bundle':
                    $itemrenderer = $this->bundleRenderer;
                    break;
            }
        }

        return $itemrenderer->setItem($item);
    }

}
