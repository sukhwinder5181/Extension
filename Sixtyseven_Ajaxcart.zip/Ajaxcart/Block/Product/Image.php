<?php
/**
 * @category  SixtySeven
 * @package   SixtySeven_Ajaxsuite
 * @author    SixtySeven https://67commerce.com/
 */
namespace SixtySeven\Ajaxcart\Block\Product;

/**
 * Image block
 */
class Image extends \Magento\Framework\View\Element\Template
{
    /**
     * @var \Magento\Framework\Registry
     */
    protected $coreRegistry;

    /**
     * @var \Magento\ConfigurableProduct\Model\Product\Type\Configurable
     */
    protected $configProductModel;

    /**
     * @var \Magento\Catalog\Model\Product
     */
    protected $productModel;

    /**
     * @var \SixtySeven\AjaxsuiteBase\Block\AbstractBlock
     */
    protected $baseBlock;

    /**
     *
     * @param \Magento\Framework\View\Element\Template\Context             $context            [description]
     * @param \SixtySeven\AjaxsuiteBase\Block\AbstractBlock                $baseBlock          [description]
     * @param \Magento\ConfigurableProduct\Model\Product\Type\Configurable $configProductModel [description]
     * @param \Magento\Catalog\Model\Product                               $productModel       [description]
     * @param \Magento\Framework\Registry                                  $registry           [description]
     * @param array                                                        $data               [description]
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \SixtySeven\AjaxsuiteBase\Block\AbstractBlock $baseBlock,
        \Magento\ConfigurableProduct\Model\Product\Type\Configurable $configProductModel,
        \Magento\Catalog\Model\Product $productModel,
        \Magento\Framework\Registry $registry,
        array $data
    ) {
        parent::__construct($context, $data);
        $this->coreRegistry       = $registry;
        $this->baseBlock          = $baseBlock;
        $this->configProductModel = $configProductModel;
        $this->productModel       = $productModel;
    }

    /**
     * getImageUrl
     * @return string
     */
    public function getImageUrl()
    {
        $Id       = $this->coreRegistry->registry('current_product')->getId();
        $product  = $this->productModel->load($Id);
        $imageUrl = $this->baseBlock->getProductImage($product, 'cart');
        return $imageUrl;
    }
}
