<?php
/**
 * @category  SixtySeven
 * @package   SixtySeven_Ajaxsuite
 * @author    SixtySeven https://67commerce.com/
 */
namespace SixtySeven\Ajaxcart\Block\Product;

use Magento\Catalog\Api\ProductRepositoryInterface;

/**
 *  product view block
 */
class View extends \Magento\Catalog\Block\Product\View
{ 
	
}