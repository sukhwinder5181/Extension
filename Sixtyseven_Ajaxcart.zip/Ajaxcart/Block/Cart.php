<?php
/**
 * @category  SixtySeven
 * @package   SixtySeven_Ajaxsuite
 * @author    SixtySeven https://67commerce.com/
 */
namespace SixtySeven\Ajaxcart\Block;

use Magento\Framework\Data\Form\FormKey;
use Magento\Framework\View\Element\Template\Context;
use SixtySeven\AjaxsuiteBase\Block\AbstractBlock;
use SixtySeven\AjaxsuiteBase\Helper\Data as SuiteHelper;

/**
 * Cart block
 */
class Cart extends \Magento\Framework\View\Element\Template
{
    /**
     * @var AbstractBlock
     */
    public $baseBlock;

    /**
     * @var SuiteHelper
     */
    protected $helper;

    /**
     * @var \Magento\Checkout\Model\Cart
     */
    protected $cart;

    /**
     * @var FormKey
     */
    protected $formkey;

    /**
     *
     * @param Context                      $context   [description]
     * @param AbstractBlock                $baseBlock [description]
     * @param SuiteHelper                  $_helper   [description]
     * @param \Magento\Checkout\Model\Cart $cart      [description]
     * @param FormKey                      $_formkey  [description]
     * @param array                        $data      [description]
     */
    public function __construct(
        Context $context,
        AbstractBlock $baseBlock,
        SuiteHelper $_helper,
        \Magento\Checkout\Model\Cart $cart,
        FormKey $_formkey,
        array $data = []
    ) {
        $this->baseBlock = $baseBlock;
        $this->helper    = $_helper;
        $this->formkey   = $_formkey;
        $this->cart      = $cart;
        parent::__construct($context, $data);
    }

    /**
     * check if current page is isProductViewPage
     * @return boolean
     */
    public function isProductViewPage()
    {
        $fullactionName = $this->getRequest()->getFullActionName();
        if ($fullactionName == 'catalog_product_view') {
            return true;
        }
        return false;
    }

    /**
     * canExecuteJs
     * check if this moduel or basemodule is enabled and also check if product view page and use in product view page is enabled
     * based on value js executes
     * @return boolean
     */
    public function canExecuteJs()
    {
        $isSuiteEnabled = $this->helper->getConfig('sixtyseven_ajax_suite/global/enabled');
        if ($isSuiteEnabled == 0) {
            return false;
        }
        if ($this->isProductViewPage()) {
            $enableOnProView = $this->helper->getConfig('ss_ajaxsuite_cart/global/eable_product_view');
            if (!$enableOnProView) {
                return false;
            } 
        } 
        $isenable = $this->helper->getConfig('ss_ajaxsuite_cart/global/enabled');
        return $isenable == '1' ? true : false;
    }

    /**
     * showRemoveConfirmation, wheather to show confirmation popup after something remove/delete
     * @return boolean
     */
    public function showRemoveConfirmation()
    {
        return (bool) $this->helper->getConfig('sixtyseven_ajax_suite/popup/show_remove_confirmation');
    }

    /**
     * canAutoClosePopup
     * @return boolean
     */
    public function canAutoClosePopup()
    {
        return (bool) $this->helper->getConfig('ss_ajaxsuite_cart/popup/auto_close');
    }

    /**
     * closePopupTime
     * @return boolean
     */
    public function closePopupTime()
    {
        return (bool) $this->helper->getConfig('ss_ajaxsuite_cart/popup/auto_close_after');
    }

    /**
     * canShowTimer
     * @return boolean
     */
    public function canShowTimer()
    {
        return (bool) $this->helper->getConfig('ss_ajaxsuite_cart/popup/show_countdown_time');
    }

    /**
     * canAutoMinicartOpen
     * @return boolean
     */
    public function canAutoMinicartOpen()
    {
        return (bool) $this->helper->getConfig('ss_ajaxsuite_cart/global/auto_minicart_open');
    }

    /**
     * canCartConfirmPopup
     * @return boolean
     */
    public function canCartConfirmPopup()
    {
        return (bool) $this->helper->getConfig('ss_ajaxsuite_cart/global/cart_confirm_popup');
    }

    /**
     * get add to cart button selector
     * @return string
     */
    public function getBtnSelector()
    {
        return $this->helper->getConfig('ss_ajaxsuite_cart/global/cart_btn_selector');
    }

    /**
     * canShowContinueBtn
     * @return boolean
     */
    public function canShowContinueBtn()
    {
        return (bool) $this->helper->getConfig('ss_ajaxsuite_cart/popup/show_continue');
    }

    /**
     * canShowCheckoutBtn
     * @return boolean
     */
    public function canShowCheckoutBtn()
    {
        return (bool) $this->helper->getConfig('ss_ajaxsuite_cart/popup/show_checkout');
    }

    /**
     * canShowCartBtn
     * @return boolean
     */
    public function canShowCartBtn()
    {
        return (bool) $this->helper->getConfig('ss_ajaxsuite_cart/popup/show_cart');
    }

    /**
     * getCartBtnText
     * @return string
     */
    public function getCartBtnText()
    {
        return $this->helper->getConfig('ss_ajaxsuite_cart/popup/cart_btn_text');
    }

    /**
     * getCheckoutBtnText
     * @return string
     */
    public function getCheckoutBtnText()
    {
        return $this->helper->getConfig('ss_ajaxsuite_cart/popup/checkout_btn_text');
    }

    /**
     * getContinueBtnText
     * @return string
     */
    public function getContinueBtnText()
    {
        return $this->helper->getConfig('ss_ajaxsuite_cart/popup/continue_btn_text');
    }

    /**
     * getItemsCount
     * @return string|int
     */
    public function getItemsCount()
    {
        return $this->cart->getItemsCount();
    }

    /**
     * getItemsQty
     * @return int
     */
    public function getItemsQty()
    {
        return $this->cart->getItemsQty();
    }

    /**
     * getSubTotal
     * @return float
     */
    public function getSubTotal()
    {
        return $this->cart->getQuote()->getSubtotal();
    }

    /**
     * getFormKey
     * @return string
     */
    public function getFormKey()
    {
        return $this->formkey->getFormKey();
    }
}
