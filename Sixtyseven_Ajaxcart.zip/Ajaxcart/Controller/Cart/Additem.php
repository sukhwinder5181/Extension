<?php
/**
 * @category  SixtySeven
 * @package   SixtySeven_Ajaxsuite
 * @author    SixtySeven https://67commerce.com/
 */
namespace SixtySeven\Ajaxcart\Controller\Cart;

use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Checkout\Model\Cart as CustomerCart; 
use Magento\Framework\Data\Form\FormKey;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Controller\ResultFactory;

/*
 * Add product to cart action
 */
class Additem extends \Magento\Checkout\Controller\Cart
{
    /**
     * layout factory
     */
    protected $layoutFactory;
    /**
     * @var ProductRepositoryInterface
     */
    protected $productRepository;

    /**
     * @var \Magento\Framework\Registry
     */
    protected $coreRegistry;

    /**
     * @var FormKey
     */
    protected $formKey; 

    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\Data\Form\FormKey\Validator $formKeyValidator
     * @param CustomerCart $cart
     * @param ProductRepositoryInterface $productRepository
     * @param \Magento\Framework\View\LayoutFactory $layoutFactory
     * @param \Magento\Framework\Registry $registry
     * @codeCoverageIgnore
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Data\Form\FormKey\Validator $formKeyValidator,
        CustomerCart $cart,
        ProductRepositoryInterface $productRepository,
        \Magento\Framework\View\LayoutFactory $layoutFactory,
        FormKey $formKey, 
        \Magento\Framework\Registry $registry
    ) {
        parent::__construct(
            $context,
            $scopeConfig,
            $checkoutSession,
            $storeManager,
            $formKeyValidator,
            $cart
        );
        $this->productRepository = $productRepository;
        $this->coreRegistry      = $registry;
        $this->layoutFactory     = $layoutFactory;
        $this->formKey           = $formKey; 
    }

    /**
     * Initialize product instance from request data
     *
     * @return \Magento\Catalog\Model\Product|false
     */
    protected function _initProduct()
    {
        $productId = (int) $this->getRequest()->getParam('product');

        if ($productId) {
            $storeId = $this->_objectManager->get(
                \Magento\Store\Model\StoreManagerInterface::class
            )->getStore()->getId();
            try {
                return $this->productRepository->getById($productId, false, $storeId);
            } catch (NoSuchEntityException $e) {
                return false;
            }
        }
        return false;
    }

    /**
     * @param  string $className [description]
     * @return object            [description]
     */
    protected function helper($className)
    {
        return $this->_objectManager->get($className);
    }

    /**
     * get url by path
     * @param  string $path [description]
     * @return string
     */
    protected function getUrl($path)
    {
        return $this->_objectManager->get('Magento\Framework\UrlInterface')->getUrl($path);
    }

    /**
     * Load the page defined in view/frontend/layout/code_index_index.xml
     *
     * @return \Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        $FormKey       = $this->formKey; 
        $return        = ['error' => true, 'content' => '', 'title' => 'Invalid Request', 'hasoption' => false, 'form_key' => $FormKey->getFormKey()];

        $params = $this->getRequest()->getParams();

        try {

            $cart = $this->_objectManager->get('\Magento\Checkout\Model\Cart');
            // get array of all items what can be display directly
            $itemsVisible = $cart->getQuote()->getAllVisibleItems();
            $currentIds   = [];
            foreach ($itemsVisible as $_item) {
                $currentIds[] = $_item->getId();
            }

            if (isset($params['qty'])) {
                $filter = new \Zend_Filter_LocalizedToNormalized(
                    ['locale' => $this->_objectManager->get(
                        \Magento\Framework\Locale\ResolverInterface::class
                    )->getLocale()]
                );
                $params['qty'] = $filter->filter($params['qty']);
            }

            $product = $this->_initProduct();
            $related = $this->getRequest()->getParam('related_product');

            /**
             * Check product availability
             */

            if (!$product) {
                throw new \Exception(__("Product not found."));
            }

            $this->cart->addProduct($product, $params);
            if (!empty($related)) {
                $this->cart->addProductsByIds(explode(',', $related));
            }

            $this->cart->save();

            /**
             * @todo remove wishlist observer \Magento\Wishlist\Observer\AddToCart
             */
            $this->_eventManager->dispatch(
                'checkout_cart_add_product_complete',
                ['product' => $product, 'request' => $this->getRequest(), 'response' => $this->getResponse()]
            );

            if (!$this->_checkoutSession->getNoCartRedirect(true)) {
                if (!$this->cart->getQuote()->getHasError()) {
                    $cart = $this->_objectManager->get('\Magento\Checkout\Model\Cart');
                    // get array of all items what can be display directly
                    $itemsVisible = $cart->getQuote()->getAllVisibleItems();
                    $nowIds       = [];
                    foreach ($itemsVisible as $_item) {
                        $nowIds[$_item->getId()] = $_item;
                    }

                    $uniteItemIds = array_diff(array_keys($nowIds), $currentIds);

                    $uniteItemIds = array_values($uniteItemIds);

                    $itemId = end($uniteItemIds);

                    $item = isset($nowIds[$itemId]) ? $nowIds[$itemId] : null;

                    if (!$item or !$item->getId()) {
                        $item = null;
                    }

                    $this->coreRegistry->unregister('current_item');
                    $this->coreRegistry->register('current_item', $item);

                    $message              = [];
                    
                    $message['success'][] = __(
                        'You added %1 to your shopping cart.',
                        $product->getName()
                    );

                    $content = $this->_prepareContenOutPut($message, $product, 'success');
                    $return  = ['error' => false, 'content' => $content, 'title' => 'Product has been added to your cart'];
                }
            }
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $message = [];
            if ($this->_checkoutSession->getUseNotice(true)) {
                $message['error'][] = $this->_objectManager->get(\Magento\Framework\Escaper::class)->escapeHtml($e->getMessage());
            } else {
                $messages = array_unique(explode("\n", $e->getMessage()));
                foreach ($messages as $_message) {
                    $message['error'][] = $this->_objectManager->get(\Magento\Framework\Escaper::class)->escapeHtml($_message);
                }
            }
            $content             = $this->_prepareContenOutPut($message, $product, 'details');
            $return              = ['error' => true, 'content' => $content, 'title' => $product->getName()];
            $return['hasoption'] = true;
        } catch (\Exception $e) {
            $message            = [];
            $message['error'][] = __('We can\'t add this item to your shopping cart right now.');
            $message['error'][] = __($e->getMessage());
            $this->_objectManager->get(\Psr\Log\LoggerInterface::class)->critical($e);
            $content = $this->_prepareContenOutPut($message, $product, 'error');
            $return  = ['error' => true, 'content' => $content, 'title' => 'Error'];
        }
        
        /** @var \Magento\Framework\Controller\Result\Json $resultJson */
        $resultJson = $this->resultFactory->create(ResultFactory::TYPE_JSON);
        $resultJson->setData($return);
        return $resultJson;
    }

    /**
     * _prepareContenOutPut
     * @param  array $message
     * @param  \Magento\Catalog\Model\Product $product
     * @param  string $type
     * @return string html content
     */
    protected function _prepareContenOutPut($message, $product, $type)
    {
        //$type = '';
        $this->coreRegistry->unregister('product');
        $this->coreRegistry->unregister('current_product');
        $this->coreRegistry->unregister('current_messages');

        $this->coreRegistry->register('product', $product);
        $this->coreRegistry->register('current_product', $product);
        $this->coreRegistry->register('current_messages', $message);
        $handles = [];
        $load    = 'default';

        switch ($type) {
            case 'details':
                $load      = 'ssajaxcart_product_view';
                $handles[] = 'catalog_product_view_type_' . $product->getTypeId();
                break;
            case 'success':
                $load = 'ssajaxcart_cart_success';
                break;
            default:
                $load = 'ssajaxcart_cart_error';
                break;
        }

        $layout = $this->layoutFactory->create();
        $layout->getUpdate()->load($load);
        $update = $layout->getUpdate();

        if (!empty($handles)) {
            foreach ($handles as $_value) {
                $update->addHandle($_value);
            }
        }
        $layout->getUpdate()->load();
        $layout->generateXml();
        $layout->generateElements();
        return $layout->getOutput();
    }
}
