<?php
/**
 * @category  SixtySeven
 * @package   SixtySeven_Ajaxsuite
 * @author    SixtySeven https://67commerce.com/
 */
namespace SixtySeven\Ajaxcart\Controller\Cart;

use Magento\Catalog\Model\Product\Exception as ProductException;
use Magento\Framework\App\Action;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Data\Form\FormKey;

/**
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Addwishlistitem extends \Magento\Wishlist\Controller\AbstractIndex
{
    /**
     * @var \Magento\Wishlist\Controller\WishlistProviderInterface
     */
    protected $wishlistProvider;

    /**
     * @var \Magento\Wishlist\Model\LocaleQuantityProcessor
     */
    protected $quantityProcessor;

    /**
     * @var \Magento\Wishlist\Model\ItemFactory
     */
    protected $itemFactory;

    /**
     * @var \Magento\Checkout\Model\Cart
     */
    protected $cart;

    /**
     * @var \Magento\Checkout\Helper\Cart
     */
    protected $cartHelper;

    /**
     * @var \Magento\Wishlist\Model\Item\OptionFactory
     */
    private $optionFactory;

    /**
     * @var \Magento\Catalog\Helper\Product
     */
    protected $productHelper;

    /**
     * @var \Magento\Framework\Escaper
     */
    protected $escaper;

    /**
     * @var \Magento\Wishlist\Helper\Data
     */
    protected $helper;

    /**
     * @var \Magento\Framework\Data\Form\FormKey\Validator
     */
    protected $formKeyValidator;

    /**
     * layout factory
     */
    protected $layoutFactory;

    /**
     * @var \Magento\Framework\Registry
     */
    protected $coreRegistry;

    /**
     * @var FormKey
     */
    protected $formKey;

    /**
     * @param Action\Context $context
     * @param \Magento\Wishlist\Controller\WishlistProviderInterface $wishlistProvider
     * @param \Magento\Wishlist\Model\LocaleQuantityProcessor $quantityProcessor
     * @param \Magento\Wishlist\Model\ItemFactory $itemFactory
     * @param \Magento\Checkout\Model\Cart $cart
     * @param \Magento\Wishlist\Model\Item\OptionFactory $optionFactory
     * @param \Magento\Catalog\Helper\Product $productHelper
     * @param \Magento\Framework\Escaper $escaper
     * @param \Magento\Wishlist\Helper\Data $helper
     * @param \Magento\Checkout\Helper\Cart $cartHelper
     * @param \Magento\Framework\Data\Form\FormKey\Validator $formKeyValidator
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
    public function __construct(
        Action\Context $context,
        \Magento\Wishlist\Controller\WishlistProviderInterface $wishlistProvider,
        \Magento\Wishlist\Model\LocaleQuantityProcessor $quantityProcessor,
        \Magento\Wishlist\Model\ItemFactory $itemFactory,
        \Magento\Checkout\Model\Cart $cart,
        \Magento\Wishlist\Model\Item\OptionFactory $optionFactory,
        \Magento\Catalog\Helper\Product $productHelper,
        \Magento\Framework\Escaper $escaper,
        \Magento\Wishlist\Helper\Data $helper,
        \Magento\Checkout\Helper\Cart $cartHelper,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\View\LayoutFactory $layoutFactory,
        FormKey $formKey,
        \Magento\Framework\Data\Form\FormKey\Validator $formKeyValidator
    ) {
        $this->wishlistProvider  = $wishlistProvider;
        $this->quantityProcessor = $quantityProcessor;
        $this->itemFactory       = $itemFactory;
        $this->cart              = $cart;
        $this->optionFactory     = $optionFactory;
        $this->productHelper     = $productHelper;
        $this->escaper           = $escaper;
        $this->helper            = $helper;
        $this->cartHelper        = $cartHelper;
        $this->formKeyValidator  = $formKeyValidator;
        $this->coreRegistry      = $registry;
        $this->layoutFactory     = $layoutFactory;
        $this->formKey           = $formKey;
        parent::__construct($context);
    }

    /**
     * Add wishlist item to shopping cart and remove from wishlist
     *
     * If Product has required options - item removed from wishlist and redirect
     * to product view page with message about needed defined required options
     *
     * @return \Magento\Framework\Controller\ResultInterface
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function execute()
    {
        $FormKey = $this->formKey;
        $result  = ['error' => true, 'content' => '', 'title' => '', 'hasoption' => false, 'form_key' => $FormKey->getFormKey()];
        if (!$this->formKeyValidator->validate($this->getRequest())) {
            $result['title']   = __('Error');
            $output            = $this->_prepareContenOutPut([__('Invalid request')], false, 'error');
            $result['content'] = $output;
            /** @var \Magento\Framework\Controller\Result\Json $resultJson */
            $resultJson = $this->resultFactory->create(ResultFactory::TYPE_JSON);
            $resultJson->setData($result);
            return $resultJson;
        }

        $itemId = (int) $this->getRequest()->getParam('item');
        /* @var $item \Magento\Wishlist\Model\Item */
        $item    = $this->itemFactory->create()->load($itemId);
        $product = $this->_objectManager->get('Magento\Catalog\Model\Product')->load($item->getProductId());

        if (!$item->getId()) {
            $result['title']   = __('Error');
            $output            = $this->_prepareContenOutPut([__('Invalid request')], $product, 'error');
            $result['content'] = $output;
            /** @var \Magento\Framework\Controller\Result\Json $resultJson */
            $resultJson = $this->resultFactory->create(ResultFactory::TYPE_JSON);
            $resultJson->setData($result);
            return $resultJson;
        }

        $wishlist = $this->wishlistProvider->getWishlist($item->getWishlistId());
        if (!$wishlist) {
            $result['title']   = __('Error');
            $output            = $this->_prepareContenOutPut([__('Invalid request')], $product, 'error');
            $result['content'] = $output;
            /** @var \Magento\Framework\Controller\Result\Json $resultJson */
            $resultJson = $this->resultFactory->create(ResultFactory::TYPE_JSON);
            $resultJson->setData($result);
            return $resultJson;
        }

        // Set qty
        $qty     = $this->getRequest()->getParam('qty');
        $postQty = $this->getRequest()->getPostValue('qty');
        if ($postQty !== null && $qty !== $postQty) {
            $qty = $postQty;
        }
        if (is_array($qty)) {
            if (isset($qty[$itemId])) {
                $qty = $qty[$itemId];
            } else {
                $qty = 1;
            }
        }
        $qty = $this->quantityProcessor->process($qty);
        if ($qty) {
            $item->setQty($qty);
        }
        try {

            $cart = $this->_objectManager->get('\Magento\Checkout\Model\Cart');
            // get array of all items what can be display directly
            $itemsVisible = $cart->getQuote()->getAllVisibleItems();
            $currentIds   = [];
            foreach ($itemsVisible as $_item) {
                $currentIds[] = $_item->getId();
            }

            /** @var \Magento\Wishlist\Model\ResourceModel\Item\Option\Collection $options */
            $options = $this->optionFactory->create()->getCollection()->addItemFilter([$itemId]);
            $item->setOptions($options->getOptionsByItem($itemId));

            $buyRequest = $this->productHelper->addParamsToBuyRequest(
                $this->getRequest()->getParams(),
                ['current_config' => $item->getBuyRequest()]
            );

            $item->mergeBuyRequest($buyRequest);
            $item->addToCart($this->cart, true);
            $this->cart->save()->getQuote()->collectTotals();
            $wishlist->save();
             
            if (!$this->cart->getQuote()->getHasError()) {
                $message = __(
                    'You added %1 to your shopping cart.',
                    $this->escaper->escapeHtml($item->getProduct()->getName())
                );
                $cart = $this->_objectManager->get('\Magento\Checkout\Model\Cart');
                // get array of all items what can be display directly
                $itemsVisible = $cart->getQuote()->getAllVisibleItems();
                $nowIds       = [];
                foreach ($itemsVisible as $_item) {
                    $nowIds[$_item->getId()] = $_item;
                }

                $uniteItemIds = array_diff(array_keys($nowIds), $currentIds);

                $uniteItemIds = array_values($uniteItemIds);

                $itemId = end($uniteItemIds);

                $item = isset($nowIds[$itemId]) ? $nowIds[$itemId] : null;

                if (!$item or !$item->getId()) {
                    $item = null;
                }

                $this->coreRegistry->unregister('current_item');
                $this->coreRegistry->register('current_item', $item);

                //$product = $this->_objectManager->get('Magento\Catalog\Model\Product')->load($item->getProductId());
                $content = $this->_prepareContenOutPut([$message], $product, 'success');
                $result  = ['error' => false, 'content' => $content, 'title' => __('Item has been added to your cart')];
                //$this->messageManager->addSuccess($message);
            }
        } catch (ProductException $e) {

            $result['title']   = __('Error');
            $output            = $this->_prepareContenOutPut([__('This product(s) is out of stock.')], $product, 'error');
            $result['content'] = $output;

        } catch (\Magento\Framework\Exception\LocalizedException $e) {

            $result['title']     = __('Information');
            $output              = $this->_prepareContenOutPut([$e->getMessage()], $product, 'details');
            $result['content']   = $output;
            $result['hasoption'] = true;

        } catch (\Exception $e) {
            //  $this->messageManager->addException($e, __('We can\'t add the item to the cart right now.'));
            $result['title']   = __('Error');
            $output            = $this->_prepareContenOutPut([__('We can\'t add the item to the cart right now.')], $product, 'error');
            $result['content'] = $output;
        }

        $this->helper->calculate();

        /** @var \Magento\Framework\Controller\Result\Json $resultJson */
        $resultJson = $this->resultFactory->create(ResultFactory::TYPE_JSON);
        $resultJson->setData($result);
        return $resultJson;
    }

    /**
     * _prepareContenOutPut
     * @param  array $message
     * @param  \Magento\Catalog\Model\Product $product
     * @param  string $type
     * @return string html content
     */
    protected function _prepareContenOutPut($message, $product, $type)
    {
        //$type = '';
        $this->coreRegistry->unregister('product');
        $this->coreRegistry->unregister('current_product');
        $this->coreRegistry->unregister('current_messages');
        if (!$product or empty($product)) {
            $product = $this->_objectManager->get('Magento\Catalog\Model\Product')->load(null);
        }
        $this->coreRegistry->register('product', $product);
        $this->coreRegistry->register('current_product', $product);
        $this->coreRegistry->register('current_messages', $message);
        $handles = [];
        $load    = 'default';
        switch ($type) {
            case 'details':
                $load      = 'ssajaxcart_product_view';
                $handles[] = 'catalog_product_view_type_' . $product->getTypeId();
                break;
            case 'success':
                $load = 'ssajaxcart_cart_success';
                break;
            default:
                $load = 'ssajaxcart_cart_error';
                break;
        }

        $layout = $this->layoutFactory->create();
        $layout->getUpdate()->load($load);
        $update = $layout->getUpdate();

        if (!empty($handles)) {
            foreach ($handles as $_value) {
                $update->addHandle($_value);
            }
        }
        $layout->getUpdate()->load();
        $layout->generateXml();
        $layout->generateElements();
        return $layout->getOutput();
    }
}
