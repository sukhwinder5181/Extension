<?php
/**
 * @category  SixtySeven
 * @package   SixtySeven_Ajaxsuite
 * @author    SixtySeven https://67commerce.com/
 */
namespace SixtySeven\Ajaxcart\Controller\Cart;

use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Data\Form\FormKey;

/**
 * Update post controller for cart page form post handler
 */
class Updatepost extends \Magento\Checkout\Controller\Cart
{
    /**
     * Empty customer's shopping cart
     *
     * @return void
     */
    protected function _emptyShoppingCart()
    {
        try {
            $this->cart->truncate()->save();
        } catch (\Magento\Framework\Exception\LocalizedException $exception) {
            $this->messageManager->addError($exception->getMessage());
        } catch (\Exception $exception) {
            $this->messageManager->addException($exception, __('We can\'t update the shopping cart.'));
        }
    }

    /**
     * Update customer's shopping cart
     *
     * @return void
     */
    protected function _updateShoppingCart()
    {
        try {
            $cartData = $this->getRequest()->getParam('cart');
            if (is_array($cartData)) {
                $filter = new \Zend_Filter_LocalizedToNormalized(
                    ['locale' => $this->_objectManager->get(
                        \Magento\Framework\Locale\ResolverInterface::class
                    )->getLocale()]
                );
                foreach ($cartData as $index => $data) {
                    if (isset($data['qty'])) {
                        $cartData[$index]['qty'] = $filter->filter(trim($data['qty']));
                    }
                }
                if (!$this->cart->getCustomerSession()->getCustomerId() && $this->cart->getQuote()->getCustomerId()) {
                    $this->cart->getQuote()->setCustomerId(null);
                }

                $cartData = $this->cart->suggestItemsQty($cartData);
                $this->cart->updateItems($cartData)->save();
            }
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->messageManager->addError(
                $this->_objectManager->get(\Magento\Framework\Escaper::class)->escapeHtml($e->getMessage())
            );
        } catch (\Exception $e) {
            $this->messageManager->addException($e, __('We can\'t update the shopping cart.'));
            $this->_objectManager->get(\Psr\Log\LoggerInterface::class)->critical($e);
        }
    }

    /**
     * Update shopping cart data action
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
        if (!$this->_formKeyValidator->validate($this->getRequest())) {
            return $this->resultRedirectFactory->create()->setPath('*/*/');
        }

        $updateAction = (string) $this->getRequest()->getParam('update_cart_action');

        switch ($updateAction) {
            case 'empty_cart':
                $this->_emptyShoppingCart();
                break;
            case 'update_qty':
                $this->_updateShoppingCart();
                break;
            default:
                $this->_updateShoppingCart();
        }
        $output                = $this->_prepareContenOutPut();
        $result                = [];
        $result['output_html'] = $output;
        $result['messages']    = $this->_prePareMessages();
        $FormKey               = $this->_objectManager->get('Magento\Framework\Data\Form\FormKey');
        $result['form_key']    = $FormKey->getFormKey();
        
        $resultJson = $this->resultFactory->create(ResultFactory::TYPE_JSON);
        $resultJson->setData($result);
        return $resultJson;
    }

    /**
     * prepare messages from message manager
     * @return array
     */
    protected function _prePareMessages()
    {
        $messages = $this->messageManager->getMessages(true);
        $return   = [];
        foreach ($messages as $_messsage) {
            $return[] = ['type' => $_messsage->getType(), 'text' => $_messsage->toString()];
        }
        return $return;
    }

    /**
     * prepare content output
     * @return string html output
     */
    protected function _prepareContenOutPut()
    {
        $layout = $this->_objectManager->get('Magento\Framework\View\LayoutFactory')->create();
        $layout->getUpdate()->addHandle('checkout_cart_ajax');
        $layout->getUpdate()->load();
        $layout->generateXml();
        $layout->generateElements();
        return $layout->getOutput();
    }
}
