<?php
/**
 * @category  SixtySeven
 * @package   SixtySeven_Ajaxsuite
 * @author    SixtySeven https://67commerce.com/
 */
namespace SixtySeven\AjaxsuiteBase\Helper;

use Magento\Framework\App\Helper\Context;

/**
 * Ajaxsuite base helper class
 * @SuppressWarnings(PHPMD.TooManyFields)
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{

    /**
     * $urlInterface
     * @var \Magento\Framework\UrlInterface
     */
    protected $urlInterface;

    /**
     * $storeManager
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    /**
     * $customerSession
     * @var \Magento\Customer\Model\Session
     */
    protected $customerSession;

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;
    
    /**
     * @param Context                                    $context
     * @param \Magento\Framework\UrlInterface            $urlInterface
     * @param \Magento\Customer\Model\Session            $_customerSession
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @codingStandardsIgnoreStart
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
    public function __construct(
        Context $context,
        \Magento\Framework\UrlInterface $urlInterface,
        \Magento\Customer\Model\Session $_customerSession,
        \Magento\Store\Model\StoreManagerInterface $storeManager
    ) {

        $this->urlInterface    = $urlInterface;
        $this->storeManager    = $storeManager;
        $this->customerSession = $_customerSession;
        $this->scopeConfig     = $context->getScopeConfig();
        parent::__construct($context);
    }

    /**
     * get media url for catalog/product
     * @return string url for media/catalog/product
     */
    public function getCatalogMediaUrl()
    {
        return $this->storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA) . '/catalog/product';
    }

    /**
     * get Store manager Object
     * @return \Magento\Store\Model\StoreManagerInterface
     */
    public function getStoreManager()
    {
        return $this->storeManager;
    }

    /**
     * Get store identifier
     *
     * @return  int
     */
    public function getStoreId()
    {
        return $this->storeManager->getStore()->getId();
    }

    /*
     * return value by config path
     * @return string
     */
    public function getConfig($path)
    {
        return $this->scopeConfig->getValue($path, \Magento\Store\Model\ScopeInterface::SCOPE_STORE, $this->getStoreId());

    }

    /**
     * getCustomerSession
     * @return \Magento\Customer\Model\Session
     */
    public function getCustomerSession()
    {
        return $this->customerSession;
    }
}
