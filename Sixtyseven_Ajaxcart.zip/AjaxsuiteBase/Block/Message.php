<?php
/**
 * @category  SixtySeven
 * @package   SixtySeven_Ajaxsuite
 * @author    SixtySeven https://67commerce.com/
 */
namespace SixtySeven\AjaxsuiteBase\Block;

/**
 * Message class to get error/success messages
 * @SuppressWarnings(PHPMD.TooManyFields)
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Message extends \Magento\Framework\View\Element\Template
{

    /**
     * coreRegistry
     * @var \Magento\Framework\Registry
     */
    private $coreRegistry;
    
    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param array $data
     * @codingStandardsIgnoreStart
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Framework\Registry $registry,
        array $data = []
    ) {
        parent::__construct(
            $context,
            $data
        );

        $this->coreRegistry = $registry;
    }

    /**
     * get success/error messages json from registry
     *
     * @return string json string
     */
    public function getMessageJs()
    {
        $return   = [];
        $messages = $this->coreRegistry->registry('current_messages');
        foreach ($messages as $type => $valueArray) {
            foreach ($valueArray as $value) {
                $return[] = ['type' => $type, 'text' => (is_string($value) ? $value : $value->__toString())];
            }
        }
        return json_encode(['messages' => $return]);
    }

}
