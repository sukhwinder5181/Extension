<?php
/**
 * @category  SixtySeven
 * @package   SixtySeven_Ajaxsuite
 * @author    SixtySeven https://67commerce.com/
 */
namespace SixtySeven\AjaxsuiteBase\Block;

use Magento\Catalog\Block\Product\ListProduct as ListProductBlock;
use Magento\Catalog\Helper\Image as ImageHelper;
use Magento\Catalog\Model\Product;
use Magento\Customer\Model\Session;
use Magento\Framework\View\Element\Template\Context;
use Magento\Store\Model\App\Emulation as AppEmulation;
use Magento\Store\Model\StoreManagerInterface;
use SixtySeven\AjaxsuiteBase\Helper\Data as SuiteHelper;

/**
 * comman block for ajax suite
 * @SuppressWarnings(PHPMD.TooManyFields)
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class AbstractBlock extends \Magento\Framework\View\Element\Template
{

    /**
     * @var Session
     */
    protected $session;

    /**
     * @var Product modal
     */
    private $productModel;

    /**
     * @var SuiteHelper Ajax suite helper
     */
    private $helper;

    /**
     * @var ImageHelper Image helper
     */
    private $imageHelper;

    /**
     * @var ListProductBlock
     */
    private $listproductblock;

    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var AppEmulation
     */
    private $appEmulation;

    /**
     *
     * @param Context               $context
     * @param Session                 $customerSession
     * @param Product                 $_productModel
     * @param SuiteHelper             $_helper
     * @param ImageHelper             $_imageHelper
     * @param ListProductBlock         $_listproductblock
     * @param StoreManagerInterface $storeManager
     * @param AppEmulation             $appEmulation
     * @param array                 $data
     * @codingStandardsIgnoreStart
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
    public function __construct(
        Context $context,
        Session $customerSession,
        Product $_productModel,
        SuiteHelper $_helper,
        ImageHelper $_imageHelper,
        ListProductBlock $_listproductblock,
        StoreManagerInterface $storeManager,
        AppEmulation $appEmulation,
        array $data = []
    ) {
        $this->session          = $customerSession;
        $this->productModel     = $_productModel;
        $this->helper           = $_helper;
        $this->imageHelper      = $_imageHelper;
        $this->listproductblock = $_listproductblock;
        $this->storeManager     = $storeManager;
        $this->appEmulation     = $appEmulation;
        parent::__construct($context, $data);
    }

    /**
     * check if current customer/visitor is logged in
     *
     * @return boolean
     */
    public function isCustomerLogedin()
    {
        return $this->session->isLoggedIn();
    }

    /**
     * get current customer object
     * @return \Magento\Customer\Model\Customer
     */
    public function getCustomer()
    {
        return $this->session->getCustomer();
    }

    /**
     * get configured image size (width*height Id, as descibed in magento2 xml for product images)
     * @param  string $suiteType  suite type cart|wishlist|compare
     * @return string
     */
    public function getImageSizeId($suiteType)
    {
        return $this->helper->getConfig('ss_ajaxsuite_' . $suiteType . '/thumb/image_size_id');
    }

    /**
     * get configured associated product type
     * @param  string $type  suite type cart|wishlist|compare
     * @return string
     */
    public function getAssociatedType($type)
    {
        return $this->helper->getConfig('ss_ajaxsuite_' . $type . '/associated_product/product_type');
    }

    /**
     * get configured associated product section title by suite type
     * @param  string $type  suite type cart|wishlist|compare
     * @return string
     */
    public function getTitleByType($type)
    {
        return $this->helper->getConfig('ss_ajaxsuite_' . $type . '/associated_product/title');
    }

    /**
     * get configured associated product max limit
     * @param  string $type  suite type cart|wishlist|compare
     * @return string
     */
    public function getAssociatedLimit($type)
    {
        return $this->helper->getConfig('ss_ajaxsuite_' . $type . '/associated_product/product_limit');
    }

    /**
     * get configured associated product collection sort order
     * @param  string $type  suite type cart|wishlist|compare
     * @return string
     */
    public function getAssociatedOrder($type)
    {
        return $this->helper->getConfig('ss_ajaxsuite_' . $type . '/associated_product/sort_order');
    }

    /**
     * get  ProductImage by product
     * @var $product product object
     * @var $type  type could be cart|wishlist|compare
     * @return string image url
     */
    public function getProductImage($product, $suiteType)
    {
        $imageSizeId = $this->getImageSizeId($suiteType);
        $this->appEmulation->startEnvironmentEmulation($this->storeManager->getStore()->getId(), \Magento\Framework\App\Area::AREA_FRONTEND, true);
        $productImage = $this->listproductblock->getImage($product, $imageSizeId);
        $imageUrl     = $productImage->getImageUrl();
        $this->appEmulation->stopEnvironmentEmulation();
        return $imageUrl;
    }

}
