/**
 * @category  SixtySeven
 * @package   SixtySeven_Ajaxsuite
 * @author    SixtySeven https://67commerce.com/
 */
define([
  'jquery',
  'mage/translate',
], function($j) {
  'use strict';
  return {
    _timerObj: false,

    _toTimeString: function(seconds) {
      return (new Date(seconds * 1000)).toUTCString().match(/(\d\d:\d\d:\d\d)/)[0];
    },

    startTimer: function(element, seconds) {
      var nextElem = $j(element); 
      var html = nextElem.html();
      var self = this;
      this._timerObj = false;

      this._timerObj = setInterval(function() {
        seconds--; 

        if (seconds >= 0) {
          nextElem.html(html + ' <b>' + $j.mage.__('In') + ' ' + self._toTimeString(seconds) + '</b>');
        }

        if (seconds === 0) {
          clearInterval(self._timerObj);
          self._timerObj = false;
          nextElem.html(html);
          element.trigger('click');
        }
      }, 1000);
    },

    getTimerObj: function() {
      return this._timerObj;
    },

    setTimerObj: function(val) {
      this._timerObj = val;
      return this;
    }
  };
});