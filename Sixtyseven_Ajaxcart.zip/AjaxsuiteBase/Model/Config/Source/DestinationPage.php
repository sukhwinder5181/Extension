<?php
/**
 * @category  SixtySeven
 * @package   SixtySeven_Ajaxsuite
 * @author    SixtySeven https://67commerce.com/
 */
namespace SixtySeven\AjaxsuiteBase\Model\Config\Source;

/**
 * allowed DestinationPage type options config class
 */
class DestinationPage implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * Options getter
     *
     * @return array
     */
    public function toOptionArray()
    {
		$return  = [];
		foreach ($this->toArray() as $key=>$val){
			$return[] = ['value' => $key, 'label' => $val];
		}
        return $return;
    }

    /**
     * Get options in "key-value" format
     *
     * @return array
     */
    public function toArray()
    {
        return ['samepage' => __('Stay on same page'), 'account' => __('On Account Dashboard'), 'homepage'=> __('On Homepage'), 'specific_page'=>__('Specific Page')];
    }
}
