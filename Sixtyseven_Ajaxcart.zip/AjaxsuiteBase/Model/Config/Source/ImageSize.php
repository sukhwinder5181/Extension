<?php
/**
 * @category  SixtySeven
 * @package   SixtySeven_Ajaxsuite
 * @author    SixtySeven https://67commerce.com/
 */
namespace SixtySeven\AjaxsuiteBase\Model\Config\Source;

/**
 * allowed ImageSize type options config class
 */
class ImageSize implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * Options getter
     *
     * @return array
     */
    public function toOptionArray()
    {
		$return  = [];
		foreach ($this->toArray() as $key=>$val){
			$return[] = ['value' => $key, 'label' => $val];
		}
        return $return;
    }

    /**
     * Get options in "key-value" format
     *
     * @return array
     */
    public function toArray()
    {
        return [
            'bundled_product_customization_page' => __('140 * 140'),
            'cart_page_product_thumbnail' => __('165 * 165'),
            'cart_cross_sell_products' => __('200 * 248'),
            'category_page_grid' => __('240 * 300'),
            'product_base_image' => __('265 * 265'),
            'product_page_image_medium' => __('700 * 560')
        ];
    }
}
