<?php
/**
 * @category  SixtySeven
 * @package   SixtySeven_Ajaxsuite
 * @author    SixtySeven https://67commerce.com/
 */
namespace SixtySeven\AjaxsuiteBase\Model\Config\Source;

/**
 * allowed associated type options config class
 */
class Associatedtype implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * Options getter
     *
     * @return array
     */
    public function toOptionArray()
    {
		$return  = [];
		foreach ($this->toArray() as $key=>$val){
			$return[] = ['value' => $key, 'label' => $val];
		}
        return $return;
    }

    /**
     * Get options in "key-value" format
     *
     * @return array
     */
    public function toArray()
    {
        return ['' => __('--None--'), 'crosssell' => __('Cross Sell Products'), 'upsell' => __('Up Sell Products'), 'related' => __('Related Products') ];
    }
}
